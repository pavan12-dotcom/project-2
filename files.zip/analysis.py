"""
=====================================================================
SALES INTELLIGENCE PLATFORM
Phase 2 & 3: EDA + Advanced Analytics
=====================================================================
"""

import pandas as pd
import numpy as np
import sqlite3
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from matplotlib.gridspec import GridSpec
import matplotlib.patches as mpatches
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import warnings
warnings.filterwarnings('ignore')

# ── Style ──────────────────────────────────────────────────────────
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.3,
    'figure.dpi': 120,
    'axes.titlesize': 13,
    'axes.titleweight': 'bold',
})
PALETTE = ['#2563EB','#16A34A','#DC2626','#D97706','#7C3AED','#0891B2','#DB2777','#65A30D']

# ── Load Data ──────────────────────────────────────────────────────
orders    = pd.read_csv('/home/claude/sales_project/data/orders.csv', parse_dates=['order_date'])
customers = pd.read_csv('/home/claude/sales_project/data/customers.csv', parse_dates=['signup_date'])
products  = pd.read_csv('/home/claude/sales_project/data/products.csv')

# Enrich orders
orders['year']       = orders['order_date'].dt.year
orders['month']      = orders['order_date'].dt.month
orders['quarter']    = orders['order_date'].dt.quarter
orders['year_month'] = orders['order_date'].dt.to_period('M')

completed = orders[orders['status'] == 'Completed'].copy()
orders_full = completed.merge(customers, on='customer_id').merge(products[['product_id','category']], on='product_id')

print("=" * 60)
print("SALES INTELLIGENCE PLATFORM — Analysis Summary")
print("=" * 60)
print(f"Total orders: {len(orders):,}")
print(f"Completed orders: {len(completed):,}")
print(f"Unique customers: {orders['customer_id'].nunique():,}")
print(f"Date range: {orders['order_date'].min().date()} → {orders['order_date'].max().date()}")
print(f"Total net revenue: ${completed['net_revenue'].sum():,.0f}")
print(f"Total gross profit: ${completed['gross_profit'].sum():,.0f}")
print(f"Avg order value: ${completed['net_revenue'].mean():.2f}")
print()

# ══════════════════════════════════════════════════════════════════
# CHART 1 — Revenue & Orders Over Time
# ══════════════════════════════════════════════════════════════════
monthly = completed.groupby('year_month').agg(
    revenue=('net_revenue','sum'),
    profit=('gross_profit','sum'),
    orders=('order_id','count')
).reset_index()
monthly['year_month_str'] = monthly['year_month'].astype(str)

fig, axes = plt.subplots(2, 1, figsize=(14, 8))
fig.suptitle('Revenue & Order Trends (2022–2024)', fontsize=15, fontweight='bold', y=1.01)

ax1 = axes[0]
ax1.fill_between(range(len(monthly)), monthly['revenue'], alpha=0.15, color=PALETTE[0])
ax1.plot(range(len(monthly)), monthly['revenue'], color=PALETTE[0], linewidth=2.5, label='Net Revenue')
ax1.plot(range(len(monthly)), monthly['profit'], color=PALETTE[1], linewidth=2, linestyle='--', label='Gross Profit')
ax1.set_xticks(range(0, len(monthly), 3))
ax1.set_xticklabels(monthly['year_month_str'][::3], rotation=45, ha='right', fontsize=8)
ax1.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x:,.0f}'))
ax1.set_title('Monthly Revenue vs Gross Profit')
ax1.legend()

ax2 = axes[1]
colors_bar = [PALETTE[0] if str(m).startswith('2022') else PALETTE[1] if str(m).startswith('2023') else PALETTE[2] for m in monthly['year_month']]
ax2.bar(range(len(monthly)), monthly['orders'], color=colors_bar, alpha=0.8)
ax2.set_xticks(range(0, len(monthly), 3))
ax2.set_xticklabels(monthly['year_month_str'][::3], rotation=45, ha='right', fontsize=8)
ax2.set_title('Monthly Order Volume')
patches = [mpatches.Patch(color=PALETTE[i], label=y) for i, y in enumerate(['2022','2023','2024'])]
ax2.legend(handles=patches)

plt.tight_layout()
plt.savefig('/home/claude/sales_project/notebooks/chart1_revenue_trend.png', bbox_inches='tight')
plt.close()
print("✓ Chart 1: Revenue trend saved")

# ══════════════════════════════════════════════════════════════════
# CHART 2 — Category & Region Analysis
# ══════════════════════════════════════════════════════════════════
cat_rev = orders_full.groupby('category').agg(
    revenue=('net_revenue','sum'),
    profit=('gross_profit','sum'),
    orders=('order_id','count')
).reset_index().sort_values('revenue', ascending=True)
cat_rev['margin'] = (cat_rev['profit'] / cat_rev['revenue'] * 100).round(1)

region_rev = orders_full.groupby('region')['net_revenue'].sum().sort_values(ascending=False)

fig, axes = plt.subplots(1, 2, figsize=(14, 6))
fig.suptitle('Revenue by Category & Region', fontsize=15, fontweight='bold')

ax = axes[0]
bars = ax.barh(cat_rev['category'], cat_rev['revenue'], color=PALETTE[:len(cat_rev)], alpha=0.85)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x/1000:.0f}K'))
for bar, margin in zip(bars, cat_rev['margin']):
    ax.text(bar.get_width() + 500, bar.get_y() + bar.get_height()/2,
            f'{margin}% margin', va='center', fontsize=8, color='gray')
ax.set_title('Revenue by Product Category')
ax.set_xlabel('Net Revenue')

ax = axes[1]
wedges, texts, autotexts = ax.pie(region_rev.values, labels=region_rev.index,
                                   autopct='%1.1f%%', colors=PALETTE[:len(region_rev)],
                                   startangle=90, pctdistance=0.82)
for t in autotexts:
    t.set_fontsize(9)
ax.set_title('Revenue Share by Region')

plt.tight_layout()
plt.savefig('/home/claude/sales_project/notebooks/chart2_category_region.png', bbox_inches='tight')
plt.close()
print("✓ Chart 2: Category & region saved")

# ══════════════════════════════════════════════════════════════════
# CHART 3 — RFM Analysis
# ══════════════════════════════════════════════════════════════════
snapshot = pd.Timestamp('2025-01-01')
rfm = completed.groupby('customer_id').agg(
    recency=('order_date', lambda x: (snapshot - x.max()).days),
    frequency=('order_id', 'nunique'),
    monetary=('net_revenue', 'sum')
).reset_index()

def score_col(series, reverse=False, bins=5):
    labels = list(range(1, bins+1))
    if reverse:
        labels = labels[::-1]
    return pd.qcut(series, bins, labels=labels, duplicates='drop').astype(int)

rfm['r'] = score_col(rfm['recency'], reverse=True)
rfm['f'] = score_col(rfm['frequency'])
rfm['m'] = score_col(rfm['monetary'])
rfm['rfm_score'] = rfm['r'] + rfm['f'] + rfm['m']

def segment(row):
    if row['rfm_score'] >= 13: return 'Champions'
    elif row['rfm_score'] >= 10: return 'Loyal'
    elif row['r'] >= 4 and row['rfm_score'] < 8: return 'Promising'
    elif row['r'] <= 2 and row['rfm_score'] >= 8: return 'At Risk'
    elif row['r'] == 1: return 'Lost'
    else: return 'Needs Attention'

rfm['segment'] = rfm.apply(segment, axis=1)
seg_counts = rfm['segment'].value_counts()
seg_revenue = rfm.merge(completed.groupby('customer_id')['net_revenue'].sum().reset_index(), on='customer_id').groupby('segment')['net_revenue'].sum()

fig, axes = plt.subplots(1, 3, figsize=(16, 6))
fig.suptitle('RFM Customer Segmentation', fontsize=15, fontweight='bold')

ax = axes[0]
ax.barh(seg_counts.index, seg_counts.values, color=PALETTE[:len(seg_counts)], alpha=0.85)
ax.set_title('Customers per Segment')
ax.set_xlabel('# Customers')
for i, v in enumerate(seg_counts.values):
    ax.text(v + 5, i, str(v), va='center', fontsize=9)

ax = axes[1]
colors_seg = [PALETTE[list(seg_counts.index).index(s)] for s in seg_revenue.index]
ax.barh(seg_revenue.index, seg_revenue.values, color=colors_seg, alpha=0.85)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x/1000:.0f}K'))
ax.set_title('Revenue per Segment')
ax.set_xlabel('Net Revenue')

ax = axes[2]
ax.scatter(rfm['frequency'], rfm['monetary'], c=rfm['rfm_score'],
           cmap='RdYlGn', alpha=0.4, s=20)
ax.set_xlabel('Frequency (# orders)')
ax.set_ylabel('Monetary ($)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x:,.0f}'))
ax.set_title('Frequency vs Monetary Value')

plt.tight_layout()
plt.savefig('/home/claude/sales_project/notebooks/chart3_rfm.png', bbox_inches='tight')
plt.close()
print("✓ Chart 3: RFM analysis saved")

# ══════════════════════════════════════════════════════════════════
# CHART 4 — Customer Cohort Analysis
# ══════════════════════════════════════════════════════════════════
completed2 = completed.copy()
completed2['cohort'] = completed2.groupby('customer_id')['order_date'].transform('min').dt.to_period('M')
completed2['period']  = completed2['order_date'].dt.to_period('M')
completed2['months_since'] = (completed2['period'] - completed2['cohort']).apply(lambda x: x.n)

cohort_data = completed2.groupby(['cohort','months_since'])['customer_id'].nunique().reset_index()
cohort_pivot = cohort_data.pivot(index='cohort', columns='months_since', values='customer_id')
cohort_pct = cohort_pivot.divide(cohort_pivot[0], axis=0) * 100

fig, ax = plt.subplots(figsize=(14, 8))
cohort_display = cohort_pct.iloc[:, :13]  # first 12 months
sns.heatmap(cohort_display.astype(float), annot=True, fmt='.0f', cmap='YlOrRd_r',
            linewidths=0.5, ax=ax, cbar_kws={'label': 'Retention %'},
            annot_kws={'size': 7})
ax.set_title('Customer Cohort Retention (%) — First 12 Months', fontsize=13, fontweight='bold')
ax.set_xlabel('Months Since First Purchase')
ax.set_ylabel('Cohort (Acquisition Month)')
ax.set_yticklabels([str(c) for c in cohort_display.index], rotation=0, fontsize=7)
plt.tight_layout()
plt.savefig('/home/claude/sales_project/notebooks/chart4_cohort.png', bbox_inches='tight')
plt.close()
print("✓ Chart 4: Cohort retention saved")

# ══════════════════════════════════════════════════════════════════
# CHART 5 — K-Means Customer Clustering
# ══════════════════════════════════════════════════════════════════
rfm_features = rfm[['recency','frequency','monetary']].copy()
scaler = StandardScaler()
rfm_scaled = scaler.fit_transform(rfm_features)

# Elbow method
inertias = []
for k in range(2, 8):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    km.fit(rfm_scaled)
    inertias.append(km.inertia_)

# Fit optimal (k=4)
km4 = KMeans(n_clusters=4, random_state=42, n_init=10)
rfm['cluster'] = km4.fit_predict(rfm_scaled)
cluster_names = {0: 'High Value', 1: 'Occasional', 2: 'At-Risk', 3: 'Low Engagement'}

cluster_summary = rfm.groupby('cluster').agg(
    customers=('customer_id','count'),
    avg_recency=('recency','mean'),
    avg_frequency=('frequency','mean'),
    avg_monetary=('monetary','mean')
).reset_index()
cluster_summary['label'] = cluster_summary['cluster'].map(cluster_names)

fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('K-Means Customer Clustering (k=4)', fontsize=15, fontweight='bold')

ax = axes[0]
ax.plot(range(2, 8), inertias, 'o-', color=PALETTE[0], linewidth=2)
ax.set_title('Elbow Curve')
ax.set_xlabel('Number of Clusters (k)')
ax.set_ylabel('Inertia')
ax.axvline(4, color='red', linestyle='--', alpha=0.5, label='Optimal k=4')
ax.legend()

ax = axes[1]
scatter = ax.scatter(rfm['frequency'], rfm['monetary'], c=rfm['cluster'],
                     cmap='tab10', alpha=0.5, s=15)
ax.set_xlabel('Frequency')
ax.set_ylabel('Monetary ($)')
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x:,.0f}'))
ax.set_title('Clusters: Frequency vs Monetary')

ax = axes[2]
x = np.arange(len(cluster_summary))
bars = ax.bar(x, cluster_summary['customers'], color=PALETTE[:4], alpha=0.85)
ax.set_xticks(x)
ax.set_xticklabels(cluster_summary['label'], rotation=15, ha='right', fontsize=9)
ax.set_title('Cluster Sizes')
ax.set_ylabel('# Customers')
for bar, val in zip(bars, cluster_summary['customers']):
    ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 5, str(val),
            ha='center', va='bottom', fontsize=9)

plt.tight_layout()
plt.savefig('/home/claude/sales_project/notebooks/chart5_clustering.png', bbox_inches='tight')
plt.close()
print("✓ Chart 5: K-Means clustering saved")

# ══════════════════════════════════════════════════════════════════
# CHART 6 — Sales Forecast (Moving Average + Trend)
# ══════════════════════════════════════════════════════════════════
monthly_rev = completed.groupby('year_month')['net_revenue'].sum().reset_index()
monthly_rev['year_month_str'] = monthly_rev['year_month'].astype(str)
monthly_rev['idx'] = range(len(monthly_rev))
monthly_rev['ma3']  = monthly_rev['net_revenue'].rolling(3).mean()
monthly_rev['ma6']  = monthly_rev['net_revenue'].rolling(6).mean()

# Simple linear trend for forecast
x = monthly_rev['idx'].values
y = monthly_rev['net_revenue'].values
z = np.polyfit(x, y, 1)
p = np.poly1d(z)

# Forecast 6 months
forecast_idx = np.arange(len(monthly_rev), len(monthly_rev) + 6)
forecast_vals = p(forecast_idx)
forecast_periods = pd.period_range(monthly_rev['year_month'].max() + 1, periods=6, freq='M')

fig, ax = plt.subplots(figsize=(14, 6))
ax.plot(monthly_rev['idx'], monthly_rev['net_revenue'], color='#94A3B8', linewidth=1.5, alpha=0.8, label='Actual Revenue')
ax.plot(monthly_rev['idx'], monthly_rev['ma3'], color=PALETTE[0], linewidth=2, label='3-Month MA')
ax.plot(monthly_rev['idx'], monthly_rev['ma6'], color=PALETTE[1], linewidth=2, linestyle='--', label='6-Month MA')
ax.plot(forecast_idx, forecast_vals, color=PALETTE[2], linewidth=2.5, linestyle=':', marker='o', markersize=6, label='6-Month Forecast')
ax.axvline(len(monthly_rev)-1, color='gray', linestyle='--', alpha=0.5)
ax.fill_between(forecast_idx, forecast_vals * 0.85, forecast_vals * 1.15, alpha=0.15, color=PALETTE[2], label='Confidence Band')

all_idx = list(monthly_rev['idx']) + list(forecast_idx)
all_labels = list(monthly_rev['year_month_str']) + [str(p) for p in forecast_periods]
tick_positions = [i for i in all_idx if i % 3 == 0]
tick_labels = [all_labels[i] for i in tick_positions if i < len(all_labels)]
ax.set_xticks(tick_positions[:len(tick_labels)])
ax.set_xticklabels(tick_labels, rotation=45, ha='right', fontsize=8)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f'${x:,.0f}'))
ax.set_title('Revenue Trend & 6-Month Forecast', fontsize=13, fontweight='bold')
ax.set_xlabel('Period')
ax.set_ylabel('Net Revenue ($)')
ax.legend(loc='upper left')

plt.tight_layout()
plt.savefig('/home/claude/sales_project/notebooks/chart6_forecast.png', bbox_inches='tight')
plt.close()
print("✓ Chart 6: Forecast saved")

# ══════════════════════════════════════════════════════════════════
# Save RFM data for Excel dashboard
# ══════════════════════════════════════════════════════════════════
rfm.to_csv('/home/claude/sales_project/data/rfm_results.csv', index=False)
monthly_rev.to_csv('/home/claude/sales_project/data/monthly_revenue.csv', index=False)

yoy = completed.groupby('year').agg(
    revenue=('net_revenue','sum'),
    orders=('order_id','count'),
    customers=('customer_id','nunique'),
    profit=('gross_profit','sum')
).reset_index()
yoy['aov'] = yoy['revenue'] / yoy['orders']
yoy['margin'] = yoy['profit'] / yoy['revenue'] * 100
yoy.to_csv('/home/claude/sales_project/data/yoy_summary.csv', index=False)

cat_summary = orders_full.groupby('category').agg(
    revenue=('net_revenue','sum'),
    profit=('gross_profit','sum'),
    orders=('order_id','count')
).reset_index()
cat_summary['margin'] = cat_summary['profit'] / cat_summary['revenue'] * 100
cat_summary['aov'] = cat_summary['revenue'] / cat_summary['orders']
cat_summary.to_csv('/home/claude/sales_project/data/category_summary.csv', index=False)

region_summary = orders_full.groupby(['region','segment']).agg(
    revenue=('net_revenue','sum'),
    orders=('order_id','count'),
    customers=('customer_id','nunique')
).reset_index()
region_summary.to_csv('/home/claude/sales_project/data/region_summary.csv', index=False)

print()
print("=" * 60)
print("All analysis complete. Data files saved for dashboard.")
print("=" * 60)
