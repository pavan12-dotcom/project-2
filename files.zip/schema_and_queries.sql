-- ============================================================
-- SALES INTELLIGENCE PLATFORM — SQL Schema & KPI Queries
-- ============================================================

-- ============================================================
-- PHASE 1: STAR SCHEMA CREATION
-- ============================================================

-- Dimension: Customers
CREATE TABLE IF NOT EXISTS dim_customers (
    customer_id     TEXT PRIMARY KEY,
    customer_name   TEXT,
    region          TEXT,
    segment         TEXT,
    signup_date     DATE
);

-- Dimension: Products
CREATE TABLE IF NOT EXISTS dim_products (
    product_id      TEXT PRIMARY KEY,
    product_name    TEXT,
    category        TEXT,
    unit_price      REAL,
    unit_cost       REAL
);

-- Dimension: Date
CREATE TABLE IF NOT EXISTS dim_date (
    date_key        TEXT PRIMARY KEY,  -- YYYY-MM-DD
    year            INTEGER,
    quarter         INTEGER,
    month           INTEGER,
    month_name      TEXT,
    week            INTEGER,
    day_of_week     TEXT,
    is_weekend      INTEGER
);

-- Fact: Orders
CREATE TABLE IF NOT EXISTS fact_orders (
    order_id        TEXT PRIMARY KEY,
    customer_id     TEXT REFERENCES dim_customers(customer_id),
    product_id      TEXT REFERENCES dim_products(product_id),
    order_date      DATE,
    quantity        INTEGER,
    payment_method  TEXT,
    status          TEXT,
    discount_pct    REAL,
    gross_revenue   REAL,
    discount_amount REAL,
    net_revenue     REAL,
    cogs            REAL,
    gross_profit    REAL
);

-- ============================================================
-- PHASE 2: KPI QUERIES
-- ============================================================

-- 1. Monthly Revenue & Profit Trend
SELECT
    strftime('%Y-%m', order_date)   AS year_month,
    COUNT(DISTINCT order_id)        AS total_orders,
    COUNT(DISTINCT customer_id)     AS unique_customers,
    ROUND(SUM(net_revenue), 2)      AS total_revenue,
    ROUND(SUM(gross_profit), 2)     AS total_profit,
    ROUND(SUM(gross_profit) * 100.0 / NULLIF(SUM(net_revenue), 0), 1) AS profit_margin_pct
FROM fact_orders
WHERE status = 'Completed'
GROUP BY year_month
ORDER BY year_month;

-- 2. Revenue by Category
SELECT
    p.category,
    COUNT(DISTINCT o.order_id)      AS orders,
    ROUND(SUM(o.net_revenue), 2)    AS revenue,
    ROUND(SUM(o.gross_profit), 2)   AS profit,
    ROUND(AVG(o.net_revenue), 2)    AS avg_order_value,
    ROUND(SUM(o.gross_profit) * 100.0 / NULLIF(SUM(o.net_revenue), 0), 1) AS margin_pct
FROM fact_orders o
JOIN dim_products p ON o.product_id = p.product_id
WHERE o.status = 'Completed'
GROUP BY p.category
ORDER BY revenue DESC;

-- 3. Revenue by Region & Segment
SELECT
    c.region,
    c.segment,
    COUNT(DISTINCT o.order_id)   AS orders,
    ROUND(SUM(o.net_revenue), 2) AS revenue
FROM fact_orders o
JOIN dim_customers c ON o.customer_id = c.customer_id
WHERE o.status = 'Completed'
GROUP BY c.region, c.segment
ORDER BY revenue DESC;

-- 4. Top 10 Customers by Revenue
SELECT
    c.customer_id,
    c.customer_name,
    c.region,
    c.segment,
    COUNT(DISTINCT o.order_id)      AS total_orders,
    ROUND(SUM(o.net_revenue), 2)    AS lifetime_value,
    ROUND(AVG(o.net_revenue), 2)    AS avg_order_value,
    MIN(o.order_date)               AS first_order,
    MAX(o.order_date)               AS last_order
FROM fact_orders o
JOIN dim_customers c ON o.customer_id = c.customer_id
WHERE o.status = 'Completed'
GROUP BY c.customer_id, c.customer_name, c.region, c.segment
ORDER BY lifetime_value DESC
LIMIT 10;

-- 5. RFM Segmentation (Recency, Frequency, Monetary)
WITH rfm_base AS (
    SELECT
        customer_id,
        JULIANDAY('2025-01-01') - JULIANDAY(MAX(order_date)) AS recency_days,
        COUNT(DISTINCT order_id)                              AS frequency,
        ROUND(SUM(net_revenue), 2)                           AS monetary
    FROM fact_orders
    WHERE status = 'Completed'
    GROUP BY customer_id
),
rfm_scored AS (
    SELECT *,
        CASE WHEN recency_days <= 30  THEN 5
             WHEN recency_days <= 90  THEN 4
             WHEN recency_days <= 180 THEN 3
             WHEN recency_days <= 365 THEN 2
             ELSE 1 END AS r_score,
        CASE WHEN frequency >= 15 THEN 5
             WHEN frequency >= 10 THEN 4
             WHEN frequency >= 6  THEN 3
             WHEN frequency >= 3  THEN 2
             ELSE 1 END AS f_score,
        CASE WHEN monetary >= 2000 THEN 5
             WHEN monetary >= 1000 THEN 4
             WHEN monetary >= 500  THEN 3
             WHEN monetary >= 200  THEN 2
             ELSE 1 END AS m_score
    FROM rfm_base
)
SELECT *,
    (r_score + f_score + m_score) AS rfm_total,
    CASE
        WHEN (r_score + f_score + m_score) >= 13 THEN 'Champions'
        WHEN (r_score + f_score + m_score) >= 10 THEN 'Loyal Customers'
        WHEN r_score >= 4 AND (f_score + m_score) < 6 THEN 'Promising'
        WHEN r_score <= 2 AND (f_score + m_score) >= 8 THEN 'At Risk'
        WHEN r_score = 1 THEN 'Lost'
        ELSE 'Needs Attention'
    END AS customer_segment
FROM rfm_scored
ORDER BY rfm_total DESC;

-- 6. Year-over-Year Growth
SELECT
    strftime('%Y', order_date)      AS year,
    ROUND(SUM(net_revenue), 2)      AS revenue,
    COUNT(DISTINCT order_id)        AS orders,
    COUNT(DISTINCT customer_id)     AS customers,
    ROUND(AVG(net_revenue), 2)      AS aov
FROM fact_orders
WHERE status = 'Completed'
GROUP BY year
ORDER BY year;

-- 7. Payment Method Analysis
SELECT
    payment_method,
    COUNT(*)                        AS transactions,
    ROUND(SUM(net_revenue), 2)      AS revenue,
    ROUND(AVG(discount_pct) * 100, 1) AS avg_discount_pct
FROM fact_orders
WHERE status = 'Completed'
GROUP BY payment_method
ORDER BY revenue DESC;

-- 8. Return & Cancellation Rate
SELECT
    status,
    COUNT(*)                        AS orders,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM fact_orders), 1) AS pct_of_total,
    ROUND(SUM(gross_revenue), 2)    AS gross_revenue_impact
FROM fact_orders
GROUP BY status
ORDER BY orders DESC;

-- 9. Cohort Retention (Monthly)
WITH first_orders AS (
    SELECT customer_id, strftime('%Y-%m', MIN(order_date)) AS cohort_month
    FROM fact_orders WHERE status = 'Completed'
    GROUP BY customer_id
),
monthly_activity AS (
    SELECT DISTINCT o.customer_id, strftime('%Y-%m', o.order_date) AS activity_month
    FROM fact_orders o WHERE o.status = 'Completed'
)
SELECT
    f.cohort_month,
    COUNT(DISTINCT f.customer_id) AS cohort_size,
    COUNT(DISTINCT CASE WHEN m.activity_month = f.cohort_month THEN f.customer_id END) AS month_0,
    COUNT(DISTINCT CASE WHEN m.activity_month = strftime('%Y-%m', date(f.cohort_month||'-01', '+1 month')) THEN f.customer_id END) AS month_1,
    COUNT(DISTINCT CASE WHEN m.activity_month = strftime('%Y-%m', date(f.cohort_month||'-01', '+3 months')) THEN f.customer_id END) AS month_3,
    COUNT(DISTINCT CASE WHEN m.activity_month = strftime('%Y-%m', date(f.cohort_month||'-01', '+6 months')) THEN f.customer_id END) AS month_6
FROM first_orders f
LEFT JOIN monthly_activity m ON f.customer_id = m.customer_id
GROUP BY f.cohort_month
ORDER BY f.cohort_month;
