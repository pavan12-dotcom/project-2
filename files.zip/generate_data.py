import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random

np.random.seed(42)
random.seed(42)

# Config
N_CUSTOMERS = 2000
N_ORDERS = 15000
START_DATE = datetime(2022, 1, 1)
END_DATE = datetime(2024, 12, 31)

REGIONS = ['North', 'South', 'East', 'West', 'Central']
SEGMENTS = ['Enterprise', 'Mid-Market', 'SMB', 'Consumer']
CATEGORIES = ['Electronics', 'Clothing', 'Home & Garden', 'Sports', 'Books', 'Beauty', 'Toys', 'Automotive']
PAYMENT_METHODS = ['Credit Card', 'Debit Card', 'PayPal', 'Bank Transfer']
STATUS_CHOICES = ['Completed', 'Completed', 'Completed', 'Returned', 'Cancelled']

# --- Customers ---
customer_ids = [f'CUST{str(i).zfill(5)}' for i in range(1, N_CUSTOMERS + 1)]
signup_dates = [START_DATE + timedelta(days=random.randint(0, 365)) for _ in range(N_CUSTOMERS)]

customers = pd.DataFrame({
    'customer_id': customer_ids,
    'customer_name': [f'Customer {i}' for i in range(1, N_CUSTOMERS + 1)],
    'region': np.random.choice(REGIONS, N_CUSTOMERS, p=[0.2, 0.2, 0.25, 0.2, 0.15]),
    'segment': np.random.choice(SEGMENTS, N_CUSTOMERS, p=[0.1, 0.2, 0.35, 0.35]),
    'signup_date': signup_dates,
    'email': [f'customer{i}@email.com' for i in range(1, N_CUSTOMERS + 1)],
})

# --- Products ---
products_list = []
pid = 1
for cat in CATEGORIES:
    for j in range(1, 16):
        base_price = {'Electronics': 250, 'Clothing': 60, 'Home & Garden': 80, 'Sports': 90,
                      'Books': 20, 'Beauty': 45, 'Toys': 35, 'Automotive': 150}[cat]
        price = round(base_price * np.random.uniform(0.5, 3.0), 2)
        cost = round(price * np.random.uniform(0.35, 0.65), 2)
        products_list.append({
            'product_id': f'PROD{str(pid).zfill(4)}',
            'product_name': f'{cat} Item {j}',
            'category': cat,
            'unit_price': price,
            'unit_cost': cost,
        })
        pid += 1

products = pd.DataFrame(products_list)

# --- Orders ---
# Weight: more orders in later years (growth trend)
date_range = pd.date_range(START_DATE, END_DATE)
weights = np.linspace(1, 2.5, len(date_range))
weights /= weights.sum()
order_dates = np.random.choice(date_range, N_ORDERS, p=weights)

# Seasonality boost: Q4 more orders
order_dates_adj = []
for d in order_dates:
    if d.month in [11, 12]:
        if random.random() < 0.3:
            d = d.replace(month=random.choice([11, 12]))
    order_dates_adj.append(pd.Timestamp(d))

sampled_customers = np.random.choice(customer_ids, N_ORDERS)
sampled_products = np.random.choice(products['product_id'].values, N_ORDERS)
quantities = np.random.choice([1, 2, 3, 4, 5], N_ORDERS, p=[0.5, 0.25, 0.12, 0.08, 0.05])

orders = pd.DataFrame({
    'order_id': [f'ORD{str(i).zfill(6)}' for i in range(1, N_ORDERS + 1)],
    'customer_id': sampled_customers,
    'product_id': sampled_products,
    'order_date': order_dates_adj,
    'quantity': quantities,
    'payment_method': np.random.choice(PAYMENT_METHODS, N_ORDERS, p=[0.45, 0.25, 0.20, 0.10]),
    'status': np.random.choice(STATUS_CHOICES, N_ORDERS),
    'discount_pct': np.random.choice([0, 0, 0, 0.05, 0.10, 0.15, 0.20], N_ORDERS),
})

# Merge pricing
orders = orders.merge(products[['product_id', 'unit_price', 'unit_cost']], on='product_id')
orders['gross_revenue'] = orders['unit_price'] * orders['quantity']
orders['discount_amount'] = orders['gross_revenue'] * orders['discount_pct']
orders['net_revenue'] = orders['gross_revenue'] - orders['discount_amount']
orders['cogs'] = orders['unit_cost'] * orders['quantity']
orders['gross_profit'] = orders['net_revenue'] - orders['cogs']

# Zero out revenue for cancelled/returned
mask = orders['status'].isin(['Returned', 'Cancelled'])
orders.loc[mask, ['net_revenue', 'gross_profit']] = 0

orders['order_date'] = pd.to_datetime(orders['order_date'])

# Save
customers.to_csv('/home/claude/sales_project/data/customers.csv', index=False)
products.to_csv('/home/claude/sales_project/data/products.csv', index=False)
orders.to_csv('/home/claude/sales_project/data/orders.csv', index=False)

print(f"Generated: {len(customers)} customers, {len(products)} products, {len(orders)} orders")
print(f"Total Net Revenue: ${orders['net_revenue'].sum():,.0f}")
print(f"Total Gross Profit: ${orders['gross_profit'].sum():,.0f}")
